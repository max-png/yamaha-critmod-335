﻿function Yamaha_OnLoad()
    this:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED");
end

function Yamaha_OnEvent(event,...)
	local timestamp, eventType, sourceGUID, sourceName, sourceFlags, destGUID, destName, destFlags = ...
	local amount, school, resisted, blocked, absorbed, critical, glancing, crushing, missType, enviromentalType
	if CombatLog_Object_IsA(sourceFlags, COMBATLOG_FILTER_MINE) then
		-- Spell
		if (eventType == "SPELL_DAMAGE") then
			spellId, spellName, spellSchool, amount, school, resisted, blocked, absorbed, critical, glancing, crushing = select(9, ...)
			if critical then
				PlaySoundFile("Interface\\AddOns\\Yamaha_Turkey\\Kalkon.mp3");
			end
		-- Damage shield
		elseif (eventType == "DAMAGE_SHIELD") then
			spellId, spellName, spellSchool, amount, school, resisted, blocked, absorbed, critical, glancing, crushing = select(9, ...)
			if critical then
				PlaySoundFile("Interface\\AddOns\\Yamaha_Turkey\\Kalkon.mp3");
			end
		-- Swing
		elseif (eventType == "SWING_DAMAGE") then
			amount, school, resisted, blocked, absorbed, critical, glancing, crushing = select(9, ...)
			if critical then
				PlaySoundFile("Interface\\AddOns\\Yamaha_Turkey\\Kalkon.mp3");
			end
		-- Range
		elseif (eventType == "RANGE_DAMAGE") then
			spellId, spellName, spellSchool, amount, school, resisted, blocked, absorbed, critical, glancing, crushing = select(9, ...)
			if critical then
				PlaySoundFile("Interface\\AddOns\\Yamaha_Turkey\\Kalkon.mp3");
			end
		-- Heal
		elseif (eventType == "SPELL_HEAL") then
			spellId, spellName, spellSchool, amount, critical = select(9, ...)
			if critical then
				PlaySoundFile("Interface\\AddOns\\Yamaha_Turkey\\Kalkon.mp3");
			end
		else
		return;
		end
	else
		return;
	end
end
