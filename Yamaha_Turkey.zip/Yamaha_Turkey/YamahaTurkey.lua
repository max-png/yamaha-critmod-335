﻿function Yamaha_OnLoad()
    this:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED");
end

sounds = {
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\wow1.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\onemoretime.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\easygame.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\myfren.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\myfren2.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\huh.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\warningcall.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\yes.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\omg.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\aldrig.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\omg2.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\djur.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\hehuh.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\oj.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\hjort.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\skjut.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\jajje.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\takeit.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\nusmaller.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\raktihjartat.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\boom.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\hehe.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\nudu.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\aldrig2.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\gahem.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\daligtraff.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\dingdingding.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\harvihan.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\bra.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\bombom.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\pls.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\blacktimber.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\timberblack.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\domedags.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\fort.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\aj.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\hejhej.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\pls2.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\ajlang.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\kung.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\simonskratt.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\hah.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\nehej.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\hueh.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\aiah.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\waah.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\hejsangrabbar.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\wuaha.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\bombedi.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\engangtill.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\energy.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\energy2.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\nukorvi.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\tjuppi.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\wahprr.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\plingpling.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\fulare.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\kling.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\ahhhh.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\jonte.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\adam.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\adam2.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\adajonte.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\adajonte2.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\svettas.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\stopp.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\kolla.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\aehmen.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\crawler.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\aa.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\aa2.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\crawler2.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\lol.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\neeeh.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\neeeh2.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\jagkommer.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\jahaeaea.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\nunu.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\nejvad.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\belzebub.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\vadhar.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\harrypotter.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\bovelen.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\harry.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\jontskratt.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\maktpendeln.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\fredrik.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\waaaah.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\fredrik2.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\jontskratt2.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\kaha.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\firstblood.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\jontnej.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\litefa.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\clarity.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\okejbra.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\pang.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\verygoodjob.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\vadskahan.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\nusmeker.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\dummer.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\du.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\du2.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\du3.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\nej2.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\wahaha.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\sant.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\matta.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\backin.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\heltotroligt.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\ljuvliga.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\ajajaj.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\ahnejnu.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\galen.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\nejlagg.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\satedet.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\nejnene.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\persson.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\hpjavel.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\yeah2.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\bangpang.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\sadusten.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\loken.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\korloken.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\korlo.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\linskvatten.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\loschken.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\hoppa.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\ododlig.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\nukomhan.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\kornu.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\kornu2.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\lokenner.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\mygod.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\mymygod.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\singthegospel.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\mygodcando.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\mygodcando2.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\thepower.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\vidare.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\12.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\mygod3.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\mygod4.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\visst.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\mygod5.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\power3.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\mygod6.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\mymymygod.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\tack.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\plint.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\bandage.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\1234nu2.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\visst2.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\jobbarvidare.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\tack2.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\jobba.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\jobba2.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\nej4.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\energi.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\nu.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\femtusen.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\intro.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\alright.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\visst3.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\sopran.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\everything.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\jattebra.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\harligt.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\holdon.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\hallelulja.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\halelul.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\halelulsjung.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\rattpa.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\halelul2.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\visstharligt.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\klapp.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\svenskt.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\klappskola.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\123arg.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\ahvisst.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\harligt3.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\ojojojah.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\wallace.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\emu.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\masken.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\adamskratt.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\adamskratt2.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\adamskratt3.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\adamskratt4.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\adamskratt5.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\adamskratt6.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\adamskratt7.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\snallatvpls.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\wrede.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\wrede2.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\windbuset.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\assistmamman.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\wah2.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\grr.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\murr.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\detrorjag.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\janej.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\nom.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\adamskratt8.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\adamskratt9.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\mmnej.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\vadfangor.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\naejj.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\bygg.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\intesakul.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\haha.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\svettig.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\ljus.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\ohmygutt.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\plz.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\varfor.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\nukemamman.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\poof.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\naenae.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\lan.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\goodtimeing.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\fetburst.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\hohoho.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\sagnidet.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\yeah.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\Kalkon.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\diefrepp.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\kalkonljud.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\lukspruta.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\noegg.mp3",
   "Interface\\AddOns\\Yamaha_Turkey\\Sounds\\tjejenkom.mp3"
}

function Yamaha_OnEvent(event,...)
	local timestamp, eventType, sourceGUID, sourceName, sourceFlags, destGUID, destName, destFlags = ...
	local amount, school, resisted, blocked, absorbed, critical, glancing, crushing, missType, enviromentalType
	if CombatLog_Object_IsA(sourceFlags, COMBATLOG_FILTER_MINE) then
		-- Spell
		if (eventType == "SPELL_DAMAGE") then
			spellId, spellName, spellSchool, amount, school, resisted, blocked, absorbed, critical, glancing, crushing = select(9, ...)
			if critical then
				playSound();
			end
		-- Damage shield
		elseif (eventType == "DAMAGE_SHIELD") then
			spellId, spellName, spellSchool, amount, school, resisted, blocked, absorbed, critical, glancing, crushing = select(9, ...)
			if critical then
				playSound();
			end
		-- Swing
		elseif (eventType == "SWING_DAMAGE") then
			amount, school, resisted, blocked, absorbed, critical, glancing, crushing = select(9, ...)
			if critical then
				playSound();
			end
		-- Range
		elseif (eventType == "RANGE_DAMAGE") then
			spellId, spellName, spellSchool, amount, school, resisted, blocked, absorbed, critical, glancing, crushing = select(9, ...)
			if critical then
				playSound();
			end
		-- Heal
		elseif (eventType == "SPELL_HEAL") then
			spellId, spellName, spellSchool, amount, critical = select(9, ...)
			if critical then
				playSound();
            end
        elseif (eventType == "PLAYER_DEATH") then
            PlaySoundFile("Interface\\AddOns\\Yamaha_Turkey\\Sounds\\Kalkon.mp3")
            local JAGDOG = "Kalkon!"
            SendChatMessage(JAGDOG, "SAY", nil, nil)
		else
		return;
		end
	else
		return;
	end
end

function playSound()
    randomSound = math.random(1, table.getn(sounds))
	PlaySoundFile(sounds[randomSound]);
end

-- test här under

local playerGUID = UnitGUID("player")
local MSG_CRITICAL_HIT = "%s crittade %s för %d skada!"
local MSG_PLAYER_DEATH = "Kalkon! %s blev död av %s!"

local f = CreateFrame("Frame")
f:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
f:SetScript("OnEvent", function(self, event)
	-- pass a variable number of arguments
    -- self:OnEvent(event, CombatLogGetCurrentEventInfo())
end)

function f:OnEvent(event, ...)
    local timestamp, subevent, _, sourceGUID, sourceName, sourceFlags, sourceRaidFlags, destGUID, destName, destFlags, destRaidFlags = ...
    local spellId, spellName, spellSchool
    local amount, overkill, school, resisted, blocked, absorbed, critical, glancing, crushing, isOffHand

    if subevent == "SWING_DAMAGE" then
        amount, overkill, school, resisted, blocked, absorbed, critical, glancing, crushing, isOffHand = select(12, ...)
    elseif subevent == "SPELL_DAMAGE" then
        spellId, spellName, spellSchool, amount, overkill, school, resisted, blocked, absorbed, critical, glancing, crushing, isOffHand = select(12, ...)
    end

    if critical and sourceGUID == playerGUID then
        local action = spellId and GetSpellLink(spellId) or MELEE
        print(MSG_CRITICAL_HIT:format(action, destName, amount))
    end

    if (event == "PARTY_KILL") then
        print(MSG_PLAYER_DEATH:format(destName, sourceName))
    end

end